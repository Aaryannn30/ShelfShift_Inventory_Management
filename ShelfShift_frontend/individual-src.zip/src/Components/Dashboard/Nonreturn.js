import React from 'react'

export default function Nonreturn() {
  return (
    <div>
     <h1>Holaa</h1> 
    </div>
  )
}
